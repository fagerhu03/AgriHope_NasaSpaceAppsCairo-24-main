package com.example.agriwise.data.model

data class RegisterBody (
    val username:String ,
    val email:String,
    val password:String
)