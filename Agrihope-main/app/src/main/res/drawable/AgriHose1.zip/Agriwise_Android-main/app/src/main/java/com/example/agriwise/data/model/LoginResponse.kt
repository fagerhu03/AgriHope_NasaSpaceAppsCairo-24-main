package com.example.agriwise.data.model

data class LoginResponse (val refresh:String, val access:String,val message:String)