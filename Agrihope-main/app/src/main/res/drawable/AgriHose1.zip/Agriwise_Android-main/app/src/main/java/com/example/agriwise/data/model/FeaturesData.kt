package com.example.agriwise.data.model

data class FeaturesData (
    val img:Int ,
    val name:String,
    val description:String
)